Stardog v4.1.3, 8 August 2016 (http://stardog.com/)

Stardog documentation can be found at http://docs.stardog.com.

Release notes for this version are available at http://docs.stardog.com/release-notes

For examples of how to use Stardog, please visit https://github.com/complexible/stardog-examples.